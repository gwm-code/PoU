// Global ambient types for Vite + React (kept minimal)
/// <reference types="vite/client" />
